class GestionMouvements
{
	constructor(tr)
  {
	this.terr=tr;
  	this.b=new Bot();
    this.numberMoves=-1;
    this.time();
  }
  time()
  {
   	let gm=this;
    setTimeout(function(){
    	gm.move(inputMoves[++gm.numberMoves].dir);
    	if(gm.numberMoves<=(inputMoves.length-2))
      	gm.time();
    },1000);
  }
  move(m)
  {
  	switch(m)
    {
      case 0: this.b.moveLeft();break;
      case 1: this.b.moveUpLeft();break;
      case 2: this.b.moveDownLeft();break;
      case 3: this.b.moveDownRight();break;
      case 4: this.b.moveUpRight();break;
      case 5: this.b.moveRight();break;
    }
    this.peindreAlentours(this.numberMoves);
  }
  
  peindreAlentours()
  {
    this.terr.ter[Math.floor((this.b.posX/32)-1)*this.terr.tailleX+Math.floor(this.b.posY/(32-6))].el.innerHTML=inputMoves[this.numberMoves].couts[0];
    this.terr.ter[Math.floor((this.b.posX/32)-1)*this.terr.tailleX+Math.floor(this.b.posY/(32-6))-1].el.innerHTML=inputMoves[this.numberMoves].couts[1];
    this.terr.ter[Math.floor((this.b.posX/32)+1)*this.terr.tailleX+Math.floor(this.b.posY/(32-6))].el.innerHTML=inputMoves[this.numberMoves].couts[2];
    this.terr.ter[(Math.floor((this.b.posX/32)+Math.ceil(this.b.posY/32)%2))*this.terr.tailleX+Math.floor(this.b.posY/(32-6))-1].el.innerHTML=inputMoves[this.numberMoves].couts[3];
    this.terr.ter[(Math.floor(((this.b.posX/32)-1)+Math.ceil(this.b.posY/32)%2))*this.terr.tailleX+Math.floor(this.b.posY/(32-6))+1].el.innerHTML=inputMoves[this.numberMoves].couts[4];
    this.terr.ter[(Math.floor(((this.b.posX/32))+Math.ceil(this.b.posY/32)%2))*this.terr.tailleX+Math.floor(this.b.posY/(32-6))+1].el.innerHTML=inputMoves[this.numberMoves].couts[5];
  }
}
